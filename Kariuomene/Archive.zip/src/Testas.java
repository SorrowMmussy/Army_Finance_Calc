import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;


abstract class Soldier {
	
	int soldierID;
	static String soldierName;
	Random IDgen = new Random();
	public int getRandomID()
	{
		return 100000+IDgen.nextInt(100000);
	}
//random name gen.
//------------------------------------------------------------------------------------------------------
	private static String[] Beginning = { "Kr", "Ca", "Ra", "Mrok", "Cru",
	         "Ray", "Bre", "Zed", "Drak", "Mor", "Jag", "Mer", "Jar", "Mjol",
	         "Zork", "Mad", "Cry", "Zur", "Creo", "Azak", "Azur", "Rei", "Cro",
	         "Mar", "Luk" };
	   private static String[] Middle = { "air", "ir", "mi", "sor", "mee", "clo",
	         "red", "cra", "ark", "arc", "miri", "lori", "cres", "mur", "zer",
	         "marac", "zoir", "slamar", "salmar", "urak" };
	   private static String[] End = { "d", "ed", "ark", "arc", "es", "er", "der",
	         "tron", "med", "ure", "zur", "cred", "mur" };
	   
	   private static Random rand = new Random();

	   public static String generateName() {

	      return Beginning[rand.nextInt(Beginning.length)] + 
	            Middle[rand.nextInt(Middle.length)]+
	            End[rand.nextInt(End.length)];
	   }
 //------------------------------------------------------------------------------------------------------
	public Soldier(){
		
		soldierName = generateName();
		soldierID = getRandomID();
	}
	
	abstract int monthlyPay ();
	abstract String soldiersInfo();
}
//------------------------------------------------------------------------------------------------------
class PrivateS extends Soldier{

	public int tariff; //abstract calc
	public int timeInArmy; //abstract calc
	public int penaltyQuant; //inner calc
	public int pushUps; //inner calc
	
	 Random gen = new Random();
		{
			timeInArmy = gen.nextInt(100-0+1);
			penaltyQuant = gen.nextInt(40-1);
			tariff = 2;
			pushUps = 100;
		}
		
	 public PrivateS(){
		 super();
	 }
	 
	public int totalPunishment(int penaltyQuant, int pushUpsPerPunishment) {
		 int quant = 0;
		if(penaltyQuant > 10) {
			quant = penaltyQuant * pushUpsPerPunishment;
		}
		else if(penaltyQuant > 20){
			quant = penaltyQuant * (pushUpsPerPunishment*2);
		}
		else if(penaltyQuant > 25) {
			quant = penaltyQuant * (pushUpsPerPunishment*5);
		}
		return quant;
	}
	 
	public int monthlyPay() {	//abstract method overwriting
		int pay = timeInArmy * tariff;
		return pay;
	}
	
	
	public String soldiersInfo() { //abstract method overwriting
		return String.format(" Uzkolojama reiksme ID: %d,  "
				+ "Vidinis param tarifas: %d, "
				+ "Vidinis param laikaskariuomeneje: %d, "
				+ "Uzklojamas metodas vardas: %s, "
				+ "Uzklojamas metodas alga:  %d, "
				+ "Vidinis metodas atsispaudimai: %d"
				, soldierID, tariff, timeInArmy, soldierName, monthlyPay(), totalPunishment(penaltyQuant,pushUps));
	}
}
//------------------------------------------------------------------------------------------------------
class Captain extends Soldier{
	
	public int tariff;
	public int timeInArmy;
	public int bonus;

	 Random gen = new Random();
		{
			timeInArmy = gen.nextInt(100-0+1);
			bonus = gen.nextInt(220-0+1);
			tariff = 4;
		}
		
	 public Captain(){
		 super();
	 }
	public int monthlyPay() {
		int pay = (timeInArmy * tariff) + bonus;
		return pay;
	}
	public String soldiersInfo() {
		return String.format(" Uzkolojama reiksme ID: %d,  "
				+ "Vidinis param tarifas: %d, "
				+ "Vidinis param laikaskariuomeneje: %d, "
				+ "Uzklojamas metodas vardas: %s, "
				+ "Uzklojamas metodas alga:  %d", soldierID, tariff, timeInArmy, soldierName, monthlyPay());
	}
}
//------------------------------------------------------------------------------------------------------
class AllSoldiers extends ArrayList<Soldier>{
	
	int biggestPay = 1;
	//public Object allsoldiers; //?????????????????
	
	int evaluateBiggestMnthPay() {
		for(int i = 0; i < 10; i++) {
			get(i).monthlyPay();
			if(get(i) instanceof PrivateS) {
				if(((PrivateS)get(i)).monthlyPay() > biggestPay) {
					biggestPay = ((PrivateS)get(i)).monthlyPay();
				}
			}
	}
		return biggestPay;
	}
}
//------------------------------------------------------------------------------------------------------
class DifferenceBetweenMostEarningSoldiers implements Comparator <AllSoldiers>{

	
	public int compare(AllSoldiers arg0, AllSoldiers arg1) {
		
		return ((AllSoldiers) arg0.allsoldiers).evaluateBiggestMnthPay() - ((AllSoldiers) arg1.allsoldiers).evaluateBiggestMnthPay();
	}
	
}
//------------------------------------------------------------------------------------------------------
class Batallion{
	
	AllSoldiers allsoldiers = new AllSoldiers();
	public static void printLine() {
		 System.out.println("------------------------------------------------------------------------------------------------");
	}
	public Batallion(){
		for(int i = 0; i < 10; i ++) {
			Random rnd = new Random();
			int randomSoldier;
			randomSoldier = rnd.nextInt(2);
			if(randomSoldier == 0) {
				allsoldiers.add(new PrivateS());
			}else {
				allsoldiers.add(new Captain());
			}
		}
	}
	public void showAllSoldiers() {
		printLine();
		for(Soldier temp:allsoldiers) {System.out.println(temp);}
		printLine();
		for(Soldier temp: allsoldiers) {System.out.println(temp.soldiersInfo());}
		printLine();
	}
	
}

//------------------------------------------------------------------------------------------------------
class Legion extends ArrayList<Batallion>{
	
	
	
	Batallion batallion1 = new Batallion(); //i kolekcija sudeti + kazkas su konstruktorium
	Batallion battalion2 = new Batallion();
	
	void sortBatallionsByMostEarningSoldier() {
		Collections.sort(this, new DifferenceBetweenMostEarningSoldiers());
	}
}
//------------------------------------------------------------------------------------------------------
public class Testas {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Legion myBigArmy = new Legion();
		myBigArmy.batallion1.showAllSoldiers();
		myBigArmy.battalion2.showAllSoldiers();
		
	}

}











//if (lastName!=null&&lastName.trim().lenght() >0){
//employees = employeesDAO.searchEmployees(lastName);
//else {
//	employees = empoyeesDAO
